#! /bin/bash
MQTT_BROKER_HOST='mqtt-broker'




